# Text Word Iterator

This app displays words one-by-one at a configurable speed and delay. Built using React and Vite, and packaged as a desktop app with Electron.

## 🚀 Development

```bash
npm install
npm run start
```

This will launch the Vite dev server and open the Electron window.

## 🛠 Build for Production

```bash
npm run build
npm run package
```

Output is in the `release/` directory.

## ⚙ Features

- Control display speed per word
- Additional delay per non-alpha character
- Adjustable thresholds and offsets
- Pause/Resume controls

## 🖥 Requirements

- Node.js >= 18
- Windows OS (for packaging .exe)